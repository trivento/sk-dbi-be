CREATE TRIGGER [dbo].[SK_TASKCLUSTER_TimeStamps] ON [dbo].[SK_TASKCLUSTER]
  AFTER INSERT, UPDATE
AS
  BEGIN

    SET NOCOUNT ON;

    IF TRIGGER_NESTLEVEL() > 1
      RETURN

    -- A bit of magic: A row that has been updated shows in the 'inserted' and 'deleted' tables on SQL Server --
    UPDATE SK_TASKCLUSTER
    SET created_on_utc = CASE WHEN deleted.TASKCLUSTER_ID IS NULL THEN GETUTCDATE() ELSE deleted.created_on_utc END,
      last_edit_on_utc = GETUTCDATE()
    FROM inserted
      LEFT JOIN deleted ON inserted.TASKCLUSTER_ID = deleted.TASKCLUSTER_ID
    WHERE inserted.TASKCLUSTER_ID = SK_TASKCLUSTER.TASKCLUSTER_ID;

  END
go

