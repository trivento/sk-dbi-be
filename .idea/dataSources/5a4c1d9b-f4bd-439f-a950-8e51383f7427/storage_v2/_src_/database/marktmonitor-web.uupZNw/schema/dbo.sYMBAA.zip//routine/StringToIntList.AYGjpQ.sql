CREATE FUNCTION [dbo].[StringToIntList]
  (@str VARCHAR(MAX), @delimeter CHAR(1))
  RETURNS
    @result TABLE(
  [ID] INT NULL)
AS
  BEGIN

    DECLARE @x XML
               SET @x = '<t>' + REPLACE(@str, @delimeter, '</t><t>') + '</t>'

    INSERT INTO @result
      SELECT
        DISTINCT x.i.value('.', 'int') AS token
      FROM @x.nodes('//t') x(i)
      ORDER BY 1

    RETURN
  END
go

