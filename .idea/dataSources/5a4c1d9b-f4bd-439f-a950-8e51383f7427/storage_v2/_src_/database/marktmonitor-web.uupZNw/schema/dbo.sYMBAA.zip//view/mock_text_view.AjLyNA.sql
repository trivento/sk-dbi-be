CREATE VIEW mock_text_view
  AS
    SELECT word, words, paragraph, (ROW_NUMBER() OVER (ORDER BY id ASC) - 1) AS rownum FROM mock_text
go

