CREATE TRIGGER [dbo].[SK_COMPETENCEQUESTION_TimeStamps] ON [dbo].[SK_COMPETENCEQUESTION]
  AFTER INSERT, UPDATE
AS
  BEGIN

    SET NOCOUNT ON;

    IF TRIGGER_NESTLEVEL() > 1
      RETURN

    -- A bit of magic: A row that has been updated shows in the 'inserted' and 'deleted' tables on SQL Server --
    UPDATE SK_COMPETENCEQUESTION
    SET created_on_utc = CASE WHEN deleted.COMPETENCEQUESTION_ID IS NULL THEN GETUTCDATE() ELSE deleted.created_on_utc END,
      last_edit_on_utc = GETUTCDATE()
    FROM inserted
      LEFT JOIN deleted ON inserted.COMPETENCEQUESTION_ID = deleted.COMPETENCEQUESTION_ID
    WHERE inserted.COMPETENCEQUESTION_ID = SK_COMPETENCEQUESTION.COMPETENCEQUESTION_ID;

  END
go

