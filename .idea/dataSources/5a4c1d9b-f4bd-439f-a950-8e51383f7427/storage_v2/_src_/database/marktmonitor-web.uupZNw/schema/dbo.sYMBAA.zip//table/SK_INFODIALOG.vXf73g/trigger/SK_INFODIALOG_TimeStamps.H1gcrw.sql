CREATE TRIGGER [dbo].[SK_INFODIALOG_TimeStamps] ON [dbo].[SK_INFODIALOG]
  AFTER INSERT, UPDATE
AS
  BEGIN

    SET NOCOUNT ON;

    IF TRIGGER_NESTLEVEL() > 1
      RETURN

    -- A bit of magic: A row that has been updated shows in the 'inserted' and 'deleted' tables on SQL Server --
    UPDATE SK_INFODIALOG
    SET created_on_utc = CASE WHEN deleted.INFODIALOG_ID IS NULL THEN GETUTCDATE() ELSE deleted.created_on_utc END,
      last_edit_on_utc = GETUTCDATE()
    FROM inserted
      LEFT JOIN deleted ON inserted.INFODIALOG_ID = deleted.INFODIALOG_ID
    WHERE inserted.INFODIALOG_ID = SK_INFODIALOG.INFODIALOG_ID;

  END
go

