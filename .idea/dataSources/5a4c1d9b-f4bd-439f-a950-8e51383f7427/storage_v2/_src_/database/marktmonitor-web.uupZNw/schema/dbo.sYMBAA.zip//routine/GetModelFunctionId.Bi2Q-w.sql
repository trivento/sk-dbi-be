CREATE FUNCTION dbo.GetModelFunctionId(@FunctionID INT)
  RETURNS INT
AS

  BEGIN
    DECLARE @currentId INT = @FunctionID;
    DECLARE @parentId INT;

    START:
    SELECT
      @parentId = parent.FUNCTIONPROFILEREVISION_ID,
      @currentId = fpr.FUNCTIONPROFILEREVISION_ID
    FROM SK_FUNCTIONPROFILEREVISION fpr
      LEFT JOIN SK_FUNCTIONPROFILEREVISION AS parent ON fpr.COPIED_FROM_PROFILE_ID = parent.FUNCTIONPROFILEREVISION_ID
    WHERE fpr.FUNCTIONPROFILEREVISION_ID = @currentId;

    IF (@parentId IS NOT NULL)
      BEGIN
        SET @currentId = @parentId;
        GOTO START;
      END

    RETURN @currentId;
  END
go

