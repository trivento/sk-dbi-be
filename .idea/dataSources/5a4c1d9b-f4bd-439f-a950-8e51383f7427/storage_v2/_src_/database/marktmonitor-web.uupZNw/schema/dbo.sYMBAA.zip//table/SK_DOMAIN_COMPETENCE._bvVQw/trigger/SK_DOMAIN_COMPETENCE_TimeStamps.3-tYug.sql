CREATE TRIGGER [dbo].[SK_DOMAIN_COMPETENCE_TimeStamps] ON [dbo].[SK_DOMAIN_COMPETENCE]
  AFTER INSERT, UPDATE
AS
  BEGIN

    SET NOCOUNT ON;

    IF TRIGGER_NESTLEVEL() > 1
      RETURN

    -- A bit of magic: A row that has been updated shows in the 'inserted' and 'deleted' tables on SQL Server --
    UPDATE SK_DOMAIN_COMPETENCE
    SET created_on_utc = CASE WHEN deleted.DOMAIN_COMPETENCE_ID IS NULL THEN GETUTCDATE() ELSE deleted.created_on_utc END,
      last_edit_on_utc = GETUTCDATE()
    FROM inserted
      LEFT JOIN deleted ON inserted.DOMAIN_COMPETENCE_ID = deleted.DOMAIN_COMPETENCE_ID
    WHERE inserted.DOMAIN_COMPETENCE_ID = SK_DOMAIN_COMPETENCE.DOMAIN_COMPETENCE_ID;

  END
go

