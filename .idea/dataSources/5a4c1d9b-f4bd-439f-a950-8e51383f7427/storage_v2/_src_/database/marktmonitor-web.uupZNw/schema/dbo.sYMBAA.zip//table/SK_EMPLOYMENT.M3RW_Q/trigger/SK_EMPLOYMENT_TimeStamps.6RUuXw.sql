CREATE TRIGGER [dbo].[SK_EMPLOYMENT_TimeStamps] ON [dbo].[SK_EMPLOYMENT]
  AFTER INSERT, UPDATE
AS
  BEGIN

    SET NOCOUNT ON;

    IF TRIGGER_NESTLEVEL() > 1
      RETURN

    -- A bit of magic: A row that has been updated shows in the 'inserted' and 'deleted' tables on SQL Server --
    UPDATE SK_EMPLOYMENT
    SET created_on_utc = CASE WHEN deleted.EMPLOYMENT_ID IS NULL THEN GETUTCDATE() ELSE deleted.created_on_utc END,
      last_edit_on_utc = GETUTCDATE()
    FROM inserted
      LEFT JOIN deleted ON inserted.EMPLOYMENT_ID = deleted.EMPLOYMENT_ID
    WHERE inserted.EMPLOYMENT_ID = SK_EMPLOYMENT.EMPLOYMENT_ID;

  END
go

