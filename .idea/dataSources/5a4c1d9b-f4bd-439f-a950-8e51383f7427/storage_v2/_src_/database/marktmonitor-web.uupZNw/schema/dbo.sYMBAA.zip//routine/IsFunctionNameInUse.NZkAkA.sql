CREATE FUNCTION dbo.IsFunctionNameInUse(@CompanyId INT, @Name NVARCHAR(256))
  RETURNS INT
AS

  BEGIN
    DECLARE @found INT = 0;

    SELECT TOP 1 @found = 1
    FROM SK_FUNCTIONPROFILEREVISION fpr
    WHERE fpr.COMPANY_ID = @CompanyId
          AND fpr.name = @Name    
    RETURN @found;
  END
go

