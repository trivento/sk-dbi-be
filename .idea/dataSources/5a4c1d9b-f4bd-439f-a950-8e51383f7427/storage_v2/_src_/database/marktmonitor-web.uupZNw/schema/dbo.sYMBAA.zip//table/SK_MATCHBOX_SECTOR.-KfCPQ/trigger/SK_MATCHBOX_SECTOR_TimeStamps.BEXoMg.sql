CREATE TRIGGER [dbo].[SK_MATCHBOX_SECTOR_TimeStamps] ON [dbo].[SK_MATCHBOX_SECTOR]
  AFTER INSERT, UPDATE
AS
  BEGIN

    SET NOCOUNT ON;

    IF TRIGGER_NESTLEVEL() > 1
      RETURN

    -- A bit of magic: A row that has been updated shows in the 'inserted' and 'deleted' tables on SQL Server --
    UPDATE SK_MATCHBOX_SECTOR
    SET created_on_utc = CASE WHEN deleted.MATCHBOX_SECTOR_ID IS NULL THEN GETUTCDATE() ELSE deleted.created_on_utc END,
      last_edit_on_utc = GETUTCDATE()
    FROM inserted
      LEFT JOIN deleted ON inserted.MATCHBOX_SECTOR_ID = deleted.MATCHBOX_SECTOR_ID
    WHERE inserted.MATCHBOX_SECTOR_ID = SK_MATCHBOX_SECTOR.MATCHBOX_SECTOR_ID;

  END
go

