CREATE TRIGGER [dbo].[SK_FUNCTION_HISTORY_TimeStamps] ON [dbo].[SK_FUNCTION_HISTORY]
  AFTER INSERT, UPDATE
AS
  BEGIN

    SET NOCOUNT ON;

    IF TRIGGER_NESTLEVEL() > 1
      RETURN

    -- A bit of magic: A row that has been updated shows in the 'inserted' and 'deleted' tables on SQL Server --
    UPDATE SK_FUNCTION_HISTORY
    SET created_on_utc = CASE WHEN deleted.FUNCTION_HISTORY_ID IS NULL THEN GETUTCDATE() ELSE deleted.created_on_utc END,
      last_edit_on_utc = GETUTCDATE()
    FROM inserted
      LEFT JOIN deleted ON inserted.FUNCTION_HISTORY_ID = deleted.FUNCTION_HISTORY_ID
    WHERE inserted.FUNCTION_HISTORY_ID = SK_FUNCTION_HISTORY.FUNCTION_HISTORY_ID;

  END
go

