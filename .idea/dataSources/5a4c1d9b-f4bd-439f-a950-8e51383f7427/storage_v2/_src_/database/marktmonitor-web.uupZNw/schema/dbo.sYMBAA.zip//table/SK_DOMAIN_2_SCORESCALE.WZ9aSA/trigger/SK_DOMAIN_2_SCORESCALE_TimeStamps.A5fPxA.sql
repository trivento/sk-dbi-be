CREATE TRIGGER [dbo].[SK_DOMAIN_2_SCORESCALE_TimeStamps] ON [dbo].[SK_DOMAIN_2_SCORESCALE]
  AFTER INSERT
AS
  BEGIN

    SET NOCOUNT ON;

    IF TRIGGER_NESTLEVEL() > 1
      RETURN

    -- A bit of magic: A row that has been updated shows in the 'inserted' and 'deleted' tables on SQL Server --
    UPDATE SK_DOMAIN_2_SCORESCALE
    SET created_on_utc = GETUTCDATE()
    FROM inserted
    WHERE inserted.DOMAIN_ID = SK_DOMAIN_2_SCORESCALE.DOMAIN_ID
      AND inserted.SCORESCALE_ID = SK_DOMAIN_2_SCORESCALE.SCORESCALE_ID;

  END
go

