CREATE TRIGGER [dbo].[SK_CREBOPROFILE_TimeStamps] ON [dbo].[SK_CREBOPROFILE]
  AFTER INSERT, UPDATE
AS
  BEGIN

    SET NOCOUNT ON;

    IF TRIGGER_NESTLEVEL() > 1
      RETURN

    -- A bit of magic: A row that has been updated shows in the 'inserted' and 'deleted' tables on SQL Server --
    UPDATE SK_CREBOPROFILE
    SET created_on_utc = CASE WHEN deleted.CREBOPROFILE_ID IS NULL THEN GETUTCDATE() ELSE deleted.created_on_utc END,
      last_edit_on_utc = GETUTCDATE()
    FROM inserted
      LEFT JOIN deleted ON inserted.CREBOPROFILE_ID = deleted.CREBOPROFILE_ID
    WHERE inserted.CREBOPROFILE_ID = SK_CREBOPROFILE.CREBOPROFILE_ID;

  END
go

