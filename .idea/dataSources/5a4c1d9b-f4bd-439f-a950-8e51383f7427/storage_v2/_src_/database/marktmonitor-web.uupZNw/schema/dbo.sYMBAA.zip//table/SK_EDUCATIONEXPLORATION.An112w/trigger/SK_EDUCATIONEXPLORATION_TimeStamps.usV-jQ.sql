CREATE TRIGGER [dbo].[SK_EDUCATIONEXPLORATION_TimeStamps] ON [dbo].[SK_EDUCATIONEXPLORATION]
  AFTER INSERT, UPDATE
AS
  BEGIN

    SET NOCOUNT ON;

    IF TRIGGER_NESTLEVEL() > 1
      RETURN

    -- A bit of magic: A row that has been updated shows in the 'inserted' and 'deleted' tables on SQL Server --
    UPDATE SK_EDUCATIONEXPLORATION
    SET created_on_utc = CASE WHEN deleted.EDUCATIONEXPLORATION_ID IS NULL THEN GETUTCDATE() ELSE deleted.created_on_utc END,
      last_edit_on_utc = GETUTCDATE()
    FROM inserted
      LEFT JOIN deleted ON inserted.EDUCATIONEXPLORATION_ID = deleted.EDUCATIONEXPLORATION_ID
    WHERE inserted.EDUCATIONEXPLORATION_ID = SK_EDUCATIONEXPLORATION.EDUCATIONEXPLORATION_ID;

  END
go

