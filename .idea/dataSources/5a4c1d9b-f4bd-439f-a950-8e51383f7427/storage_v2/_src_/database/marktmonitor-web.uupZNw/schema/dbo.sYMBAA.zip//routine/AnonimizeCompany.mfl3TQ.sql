CREATE PROCEDURE dbo.AnonimizeCompany
    @CompanyId NUMERIC(19, 0)
AS
  BEGIN
    DECLARE @PersonId AS NUMERIC(19, 0);
    DECLARE @PersonCursor AS CURSOR;

    UPDATE c
      SET c.NAME = mc.name + '_' + CONVERT(VARCHAR(19), c.COMPANY_ID),
        c.DESCRIPTION = CASE WHEN NULLIF(c.DESCRIPTION, '') IS NULL THEN NULL ELSE mc.description END,
        c.COMPANY_CODE = CONVERT(VARCHAR(19), c.COMPANY_ID) + SUBSTRING(mc.name, 1, 4),
        c.TELEPHONE = CASE WHEN NULLIF(c.TELEPHONE, '') IS NULL THEN NULL ELSE mc.phone END,
        c.ADDRESS = CASE WHEN NULLIF(c.ADDRESS, '') IS NULL THEN NULL ELSE addr.address END,
        c.ZIP = CASE WHEN NULLIF(c.ZIP, '') IS NULL THEN NULL ELSE addr.zip_code END,
        c.EMAIL = CASE WHEN NULLIF(c.EMAIL, '') IS NULL THEN NULL ELSE 'company_' + CONVERT(VARCHAR(19), c.COMPANY_ID) + '@skillskompas.nl' END,
        c.CITY = CASE WHEN NULLIF(c.CITY, '') IS NULL THEN NULL ELSE addr.city END,
        c.PDFLOGO = CASE WHEN NULLIF(c.PDFLOGO, '') IS NULL THEN NULL ELSE 'https://placeimg.com/150/100/arch' END
      FROM SK_COMPANY AS c,
        (SELECT TOP 1 * FROM mock_company ORDER BY NEWID()) AS mc,
        (SELECT TOP 1 * FROM mock_address ORDER BY NEWID()) AS addr
      WHERE c.COMPANY_ID = @CompanyId;


    SET @PersonCursor = CURSOR FOR SELECT DISTINCT p.PERSON_ID FROM SK_PERSON AS p
      LEFT JOIN SK_ACCOUNT AS a ON a.PERSON_ID = p.PERSON_ID
    WHERE a.COMPANY_ID = @CompanyId ORDER BY p.PERSON_ID;

    OPEN @PersonCursor;

    FETCH NEXT FROM @PersonCursor INTO @PersonId;
    WHILE @@FETCH_STATUS = 0
      BEGIN

        EXEC dbo.AnonimizePerson @PersonId;

        FETCH NEXT FROM @PersonCursor INTO @PersonId;
      END

    CLOSE @PersonCursor;
    DEALLOCATE @PersonCursor;
  END
go

