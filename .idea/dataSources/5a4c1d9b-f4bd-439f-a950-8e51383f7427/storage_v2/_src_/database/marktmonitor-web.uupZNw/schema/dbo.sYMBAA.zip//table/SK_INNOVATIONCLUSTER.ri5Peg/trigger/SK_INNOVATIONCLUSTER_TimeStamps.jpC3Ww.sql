CREATE TRIGGER [dbo].[SK_INNOVATIONCLUSTER_TimeStamps] ON [dbo].[SK_INNOVATIONCLUSTER]
  AFTER INSERT, UPDATE
AS
  BEGIN

    SET NOCOUNT ON;

    IF TRIGGER_NESTLEVEL() > 1
      RETURN

    -- A bit of magic: A row that has been updated shows in the 'inserted' and 'deleted' tables on SQL Server --
    UPDATE SK_INNOVATIONCLUSTER
    SET created_on_utc = CASE WHEN deleted.INNOVATIONCLUSTER_ID IS NULL THEN GETUTCDATE() ELSE deleted.created_on_utc END,
      last_edit_on_utc = GETUTCDATE()
    FROM inserted
      LEFT JOIN deleted ON inserted.INNOVATIONCLUSTER_ID = deleted.INNOVATIONCLUSTER_ID
    WHERE inserted.INNOVATIONCLUSTER_ID = SK_INNOVATIONCLUSTER.INNOVATIONCLUSTER_ID;

  END
go

