CREATE FUNCTION dbo.CreateFunctionName(@CompanyId INT, @Name NVARCHAR(256))
  RETURNS NVARCHAR(256)
AS

  BEGIN
    DECLARE @current NVARCHAR(256) = @Name;
    DECLARE @inUse INT;
    DECLARE @counter INT = 2;

    START:
    SET @inUse = dbo.IsFunctionNameInUse(@CompanyId, @current);

    IF (@inUse = 1)
      BEGIN
        SET @current = concat(@Name, ' ', @counter );
        SET @counter = @counter + 1;
        GOTO START;
      END
    RETURN @current;
  END
go

