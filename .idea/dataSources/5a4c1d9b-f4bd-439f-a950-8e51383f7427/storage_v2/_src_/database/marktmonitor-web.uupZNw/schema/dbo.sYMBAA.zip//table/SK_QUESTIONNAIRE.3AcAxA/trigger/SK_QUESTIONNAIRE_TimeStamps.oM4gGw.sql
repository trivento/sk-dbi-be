CREATE TRIGGER [dbo].[SK_QUESTIONNAIRE_TimeStamps] ON [dbo].[SK_QUESTIONNAIRE]
  AFTER INSERT, UPDATE
AS
  BEGIN

    SET NOCOUNT ON;

    IF TRIGGER_NESTLEVEL() > 1
      RETURN

    -- A bit of magic: A row that has been updated shows in the 'inserted' and 'deleted' tables on SQL Server --
    UPDATE SK_QUESTIONNAIRE
    SET created_on_utc = CASE WHEN deleted.QUESTIONNAIRE_ID IS NULL THEN GETUTCDATE() ELSE deleted.created_on_utc END,
      last_edit_on_utc = GETUTCDATE()
    FROM inserted
      LEFT JOIN deleted ON inserted.QUESTIONNAIRE_ID = deleted.QUESTIONNAIRE_ID
    WHERE inserted.QUESTIONNAIRE_ID = SK_QUESTIONNAIRE.QUESTIONNAIRE_ID;

  END
go

