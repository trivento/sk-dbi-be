CREATE TRIGGER [dbo].[sk_development_plan_goal_TimeStamps] ON [dbo].[sk_development_plan_goal]
  AFTER INSERT, UPDATE
AS
  BEGIN

    SET NOCOUNT ON;

    IF TRIGGER_NESTLEVEL() > 1
      RETURN

    -- A bit of magic: A row that has been updated shows in the 'inserted' and 'deleted' tables on SQL Server --
    UPDATE sk_development_plan_goal
    SET created_on_utc = CASE WHEN deleted.id IS NULL THEN GETUTCDATE() ELSE deleted.created_on_utc END,
      last_edit_on_utc = GETUTCDATE()
    FROM inserted
      LEFT JOIN deleted ON inserted.id = deleted.id
    WHERE inserted.id = sk_development_plan_goal.id;

  END
go

