CREATE TRIGGER [dbo].[SK_SYSTEMMESSAGE_TimeStamps] ON [dbo].[SK_SYSTEMMESSAGE]
  AFTER INSERT, UPDATE
AS
  BEGIN

    SET NOCOUNT ON;

    IF TRIGGER_NESTLEVEL() > 1
      RETURN

    -- A bit of magic: A row that has been updated shows in the 'inserted' and 'deleted' tables on SQL Server --
    UPDATE SK_SYSTEMMESSAGE
    SET created_on_utc = CASE WHEN deleted.SYSTEMMESSAGE_ID IS NULL THEN GETUTCDATE() ELSE deleted.created_on_utc END,
      last_edit_on_utc = GETUTCDATE()
    FROM inserted
      LEFT JOIN deleted ON inserted.SYSTEMMESSAGE_ID = deleted.SYSTEMMESSAGE_ID
    WHERE inserted.SYSTEMMESSAGE_ID = SK_SYSTEMMESSAGE.SYSTEMMESSAGE_ID;

  END
go

