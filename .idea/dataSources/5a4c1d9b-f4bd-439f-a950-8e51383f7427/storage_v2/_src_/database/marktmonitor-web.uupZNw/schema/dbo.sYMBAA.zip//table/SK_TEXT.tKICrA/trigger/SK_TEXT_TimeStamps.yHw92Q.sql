CREATE TRIGGER [dbo].[SK_TEXT_TimeStamps] ON [dbo].[SK_TEXT]
  AFTER INSERT, UPDATE
AS
  BEGIN

    SET NOCOUNT ON;

    IF TRIGGER_NESTLEVEL() > 1
      RETURN

    -- A bit of magic: A row that has been updated shows in the 'inserted' and 'deleted' tables on SQL Server --
    UPDATE SK_TEXT
    SET created_on_utc = CASE WHEN deleted.TEXT_ID IS NULL THEN GETUTCDATE() ELSE deleted.created_on_utc END,
      last_edit_on_utc = GETUTCDATE()
    FROM inserted
      LEFT JOIN deleted ON inserted.TEXT_ID = deleted.TEXT_ID
    WHERE inserted.TEXT_ID = SK_TEXT.TEXT_ID;

  END
go

