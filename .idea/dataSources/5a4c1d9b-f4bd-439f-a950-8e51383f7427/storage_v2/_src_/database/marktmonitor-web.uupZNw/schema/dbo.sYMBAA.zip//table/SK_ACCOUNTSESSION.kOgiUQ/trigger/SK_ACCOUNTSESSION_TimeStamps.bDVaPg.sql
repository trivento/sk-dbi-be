CREATE TRIGGER [dbo].[SK_ACCOUNTSESSION_TimeStamps] ON [dbo].[SK_ACCOUNTSESSION]
  AFTER INSERT, UPDATE
AS
  BEGIN

    SET NOCOUNT ON;

    IF TRIGGER_NESTLEVEL() > 1
      RETURN

    -- A bit of magic: A row that has been updated shows in the 'inserted' and 'deleted' tables on SQL Server --
    UPDATE SK_ACCOUNTSESSION
    SET created_on_utc = CASE WHEN deleted.ACCOUNTSESSION_ID IS NULL THEN GETUTCDATE() ELSE deleted.created_on_utc END,
      last_edit_on_utc = GETUTCDATE()
    FROM inserted
      LEFT JOIN deleted ON inserted.ACCOUNTSESSION_ID = deleted.ACCOUNTSESSION_ID
    WHERE SK_ACCOUNTSESSION.ACCOUNTSESSION_ID = inserted.ACCOUNTSESSION_ID;

  END
go

