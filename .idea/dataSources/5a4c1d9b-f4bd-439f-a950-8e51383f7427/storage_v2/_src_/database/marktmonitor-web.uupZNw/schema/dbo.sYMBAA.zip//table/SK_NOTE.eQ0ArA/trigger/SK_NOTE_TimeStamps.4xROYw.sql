CREATE TRIGGER [dbo].[SK_NOTE_TimeStamps] ON [dbo].[SK_NOTE]
  AFTER INSERT, UPDATE
AS
  BEGIN

    SET NOCOUNT ON;

    IF TRIGGER_NESTLEVEL() > 1
      RETURN

    -- A bit of magic: A row that has been updated shows in the 'inserted' and 'deleted' tables on SQL Server --
    UPDATE SK_NOTE
    SET created_on_utc = CASE WHEN deleted.NOTE_ID IS NULL THEN GETUTCDATE() ELSE deleted.created_on_utc END,
      last_edit_on_utc = GETUTCDATE()
    FROM inserted
      LEFT JOIN deleted ON inserted.NOTE_ID = deleted.NOTE_ID
    WHERE inserted.NOTE_ID = SK_NOTE.NOTE_ID;

  END
go

