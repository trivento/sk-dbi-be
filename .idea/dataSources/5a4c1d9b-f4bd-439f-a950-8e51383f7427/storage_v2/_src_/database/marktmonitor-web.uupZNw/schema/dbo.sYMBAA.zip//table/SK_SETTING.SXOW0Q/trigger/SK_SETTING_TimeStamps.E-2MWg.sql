CREATE TRIGGER [dbo].[SK_SETTING_TimeStamps] ON [dbo].[SK_SETTING]
  AFTER INSERT, UPDATE
AS
  BEGIN

    SET NOCOUNT ON;

    IF TRIGGER_NESTLEVEL() > 1
      RETURN

    -- A bit of magic: A row that has been updated shows in the 'inserted' and 'deleted' tables on SQL Server --
    UPDATE SK_SETTING
    SET created_on_utc = CASE WHEN deleted.setting_id IS NULL THEN GETUTCDATE() ELSE deleted.created_on_utc END,
      last_edit_on_utc = GETUTCDATE()
    FROM inserted
      LEFT JOIN deleted ON inserted.setting_id = deleted.setting_id
    WHERE inserted.setting_id = SK_SETTING.setting_id;

  END
go

