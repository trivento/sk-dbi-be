CREATE TRIGGER [dbo].[SK_REVIEW_TimeStamps] ON [dbo].[SK_REVIEW]
  AFTER INSERT, UPDATE
AS
  BEGIN

    SET NOCOUNT ON;

    IF TRIGGER_NESTLEVEL() > 1
      RETURN

    -- A bit of magic: A row that has been updated shows in the 'inserted' and 'deleted' tables on SQL Server --
    UPDATE SK_REVIEW
    SET created_on_utc = CASE WHEN deleted.REVIEW_ID IS NULL THEN GETUTCDATE() ELSE deleted.created_on_utc END,
      last_edit_on_utc = GETUTCDATE()
    FROM inserted
      LEFT JOIN deleted ON inserted.REVIEW_ID = deleted.REVIEW_ID
    WHERE inserted.REVIEW_ID = SK_REVIEW.REVIEW_ID;

  END
go

