CREATE TRIGGER [dbo].[SK_RIGHT_TimeStamps] ON [dbo].[SK_RIGHT]
  AFTER INSERT, UPDATE
AS
  BEGIN

    SET NOCOUNT ON;

    IF TRIGGER_NESTLEVEL() > 1
      RETURN

    -- A bit of magic: A row that has been updated shows in the 'inserted' and 'deleted' tables on SQL Server --
    UPDATE SK_RIGHT
    SET created_on_utc = CASE WHEN deleted.RIGHT_ID IS NULL THEN GETUTCDATE() ELSE deleted.created_on_utc END,
      last_edit_on_utc = GETUTCDATE()
    FROM inserted
      LEFT JOIN deleted ON inserted.RIGHT_ID = deleted.RIGHT_ID
    WHERE inserted.RIGHT_ID = SK_RIGHT.RIGHT_ID;

  END
go

