CREATE TRIGGER [dbo].[sk_url_sector_TimeStamps] ON [dbo].[sk_url_sector]
  AFTER INSERT
AS
  BEGIN

    SET NOCOUNT ON;

    IF TRIGGER_NESTLEVEL() > 1
      RETURN

    UPDATE sk_url_sector
    SET created_on_utc = GETUTCDATE()
    FROM inserted
    WHERE sk_url_sector.url_id = inserted.url_id
          AND sk_url_sector.sector_id = inserted.sector_id;

  END
go

