CREATE TRIGGER [dbo].[SK_ACTIONS_TimeStamps] ON [dbo].[SK_ACTIONS]
  AFTER INSERT, UPDATE
AS
  BEGIN

    SET NOCOUNT ON;

    IF TRIGGER_NESTLEVEL() > 1
      RETURN

    -- A bit of magic: A row that has been updated shows in the 'inserted' and 'deleted' tables on SQL Server --
    UPDATE SK_ACTIONS
    SET created_on_utc = CASE WHEN deleted.ACTION_ID IS NULL THEN GETUTCDATE() ELSE deleted.created_on_utc END,
      last_edit_on_utc = GETUTCDATE()
    FROM inserted
      LEFT JOIN deleted ON inserted.ACTION_ID = deleted.ACTION_ID
    WHERE SK_ACTIONS.ACTION_ID = inserted.ACTION_ID;

  END
go

