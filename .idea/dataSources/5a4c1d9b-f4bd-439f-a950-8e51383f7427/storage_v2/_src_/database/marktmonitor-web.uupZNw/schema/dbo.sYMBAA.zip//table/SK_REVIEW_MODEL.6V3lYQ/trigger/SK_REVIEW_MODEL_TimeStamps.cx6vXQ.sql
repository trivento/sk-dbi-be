CREATE TRIGGER [dbo].[SK_REVIEW_MODEL_TimeStamps] ON [dbo].[SK_REVIEW_MODEL]
  AFTER INSERT, UPDATE
AS
  BEGIN

    SET NOCOUNT ON;

    IF TRIGGER_NESTLEVEL() > 1
      RETURN

    -- A bit of magic: A row that has been updated shows in the 'inserted' and 'deleted' tables on SQL Server --
    UPDATE SK_REVIEW_MODEL
    SET created_on_utc = CASE WHEN deleted.REVIEW_MODEL_ID IS NULL THEN GETUTCDATE() ELSE deleted.created_on_utc END,
      last_edit_on_utc = GETUTCDATE()
    FROM inserted
      LEFT JOIN deleted ON inserted.REVIEW_MODEL_ID = deleted.REVIEW_MODEL_ID
    WHERE inserted.REVIEW_MODEL_ID = SK_REVIEW_MODEL.REVIEW_MODEL_ID;

  END
go

