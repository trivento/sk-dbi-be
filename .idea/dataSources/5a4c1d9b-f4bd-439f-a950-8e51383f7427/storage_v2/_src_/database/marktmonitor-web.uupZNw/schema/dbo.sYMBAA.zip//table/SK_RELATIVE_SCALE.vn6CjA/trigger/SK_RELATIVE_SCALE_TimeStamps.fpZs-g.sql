CREATE TRIGGER [dbo].[SK_RELATIVE_SCALE_TimeStamps] ON [dbo].[SK_RELATIVE_SCALE]
  AFTER INSERT, UPDATE
AS
  BEGIN

    SET NOCOUNT ON;

    IF TRIGGER_NESTLEVEL() > 1
      RETURN

    -- A bit of magic: A row that has been updated shows in the 'inserted' and 'deleted' tables on SQL Server --
    UPDATE SK_RELATIVE_SCALE
    SET created_on_utc = CASE WHEN deleted.SCALE_ID IS NULL THEN GETUTCDATE() ELSE deleted.created_on_utc END,
      last_edit_on_utc = GETUTCDATE()
    FROM inserted
      LEFT JOIN deleted ON inserted.SCALE_ID = deleted.SCALE_ID
    WHERE inserted.SCALE_ID = SK_RELATIVE_SCALE.SCALE_ID;

  END
go

