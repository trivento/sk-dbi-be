CREATE PROCEDURE dbo.AnonimizePerson
    @PersonId NUMERIC(19, 0)
AS
BEGIN
  BEGIN TRANSACTION;
  SAVE TRANSACTION AnonimizeSavePoint;

  BEGIN TRY

  DECLARE @MTextCount INT;
  SET @MTextCount = (SELECT COUNT(*) FROM mock_text_view);

  UPDATE SK_ACCOUNT SET USERNAME = 'user' + CONVERT(VARCHAR(19), ACCOUNT_ID) + '@skillskompas.nl',
    PASSWORD = NULL
  WHERE PERSON_ID = @PersonId;

  UPDATE p
  SET
    p.INITIALS     = CASE WHEN NULLIF(p.INITIALS, '') IS NULL THEN NULL ELSE firstName.initials END,
    p.FIRST_NAME   = firstName.first_name,
    p.LAST_NAME    = lastName.last_name,
    p.ADDRESS      = CASE WHEN NULLIF(p.ADDRESS, '') IS NULL THEN NULL ELSE addr.address END,
    p.ZIP          = CASE WHEN NULLIF(p.ZIP, '') IS NULL THEN NULL ELSE addr.zip_code  END,
    p.CITY         = CASE WHEN NULLIF(p.CITY, '') IS NULL THEN NULL ELSE addr.city  END,
    p.COUNTRY      = CASE WHEN NULLIF(p.COUNTRY, '') IS NULL THEN NULL ELSE addr.country_code  END,
    p.PHONE        = CASE WHEN NULLIF(p.PHONE, '') IS NULL THEN NULL ELSE (SELECT TOP 1 phone_number FROM mock_person ORDER BY NEWID()) END,
    p.BIRTH_DATE   = CASE WHEN NULLIF(p.BIRTH_DATE, '') IS NULL THEN NULL ELSE birth.date_of_birth END,
    p.BIRTH_PLACE  = CASE WHEN NULLIF(p.BIRTH_PLACE, '') IS NULL THEN NULL ELSE birth.place_of_birth END,
    p.GENDER       = CASE WHEN NULLIF(p.GENDER, '') IS NULL THEN NULL ELSE (SELECT TOP 1 gender FROM mock_person ORDER BY NEWID()) END,
    p.PICTURE      = CASE WHEN NULLIF(p.PICTURE, '') IS NULL THEN NULL ELSE 'https://placeimg.com/100/100/people' END,
    p.EMAIL        = CASE WHEN NULLIF(p.EMAIL, '') IS NULL THEN NULL ELSE LOWER(CONVERT(VARCHAR(MAX), firstName.initials + lastName.last_name + '-' + CONVERT(VARCHAR(MAX), p.PERSON_ID) + '@skillskompas.nl')) END
  FROM SK_PERSON AS p,
    (SELECT TOP 1 address, zip_code, country_code, city FROM mock_address ORDER BY NEWID()) AS addr,
    (SELECT TOP 1 initials, first_name FROM mock_person ORDER BY NEWID()) AS firstName,
    (SELECT TOP 1 last_name FROM mock_person ORDER BY NEWID()) as lastName,
    (SELECT TOP 1 date_of_birth, place_of_birth FROM mock_person ORDER BY NEWID()) as birth
  WHERE p.PERSON_ID = @PersonId;

  UPDATE a
  SET
    a.NAME = mock.words,
    a.DESCRIPTION = mock.paragraph
  FROM SK_ACTIONS AS a
    JOIN mock_text_view AS mock ON mock.rownum = (a.ACTION_ID % @MTextCount) + 1
  WHERE a.ABOUT_PERSON_ID = @PersonId;

  UPDATE a
  SET
    a.ANSWER_TEXT = mock.words
  FROM SK_ANSWER AS a
    JOIN SK_REVIEW AS r ON r.ANSWERSET_ID = a.ANSWERSET_ID
    JOIN SK_EMPLOYMENT e ON r.REVIEWEE_EMPLOYMENT_ID = e.EMPLOYMENT_ID
    JOIN mock_text_view AS mock ON mock.rownum = (a.ANSWERSET_ID + a.QUESTION_ID) % @MTextCount
  WHERE a.ANSWER_TEXT IS NOT NULL
        AND e.PERSON_ID = @PersonId;

  UPDATE p
  SET p.title = mock.words,
    p.motivation = CASE WHEN NULLIF(p.motivation, '') IS NULL THEN NULL ELSE mock.paragraph END
  FROM sk_development_plan AS p
    JOIN mock_text_view AS mock ON mock.rownum = p.id % @MTextCount
  WHERE p.person_id = @PersonId;

  UPDATE c
  SET c.message = mock.paragraph
  FROM sk_development_plan_comment AS c
    JOIN sk_development_plan AS p ON c.plan_id = p.id
    JOIN mock_text_view AS mock ON mock.rownum = c.id % @MTextCount
  WHERE p.person_id = @PersonId
        AND c.message IS NOT NULL;

  UPDATE g
  SET g.title = mock.words,
    g.supported_by = NULL,
    g.result = CASE WHEN NULLIF(g.result, '') IS NULL THEN NULL ELSE mock.paragraph END,
    g.motivation = CASE WHEN NULLIF(g.motivation, '') IS NULL THEN NULL ELSE (SELECT paragraph FROM mock_text_view WHERE rownum = (g.id + 1) % @MTextCount) END,
    g.actions = CASE WHEN NULLIF(g.actions, '') IS NULL THEN NULL ELSE (SELECT paragraph FROM mock_text_view WHERE rownum = (g.id + 2) % @MTextCount) END
  FROM sk_development_plan_goal AS g
    JOIN sk_development_plan AS p ON g.plan_id = p.id
    JOIN mock_text_view AS mock ON mock.rownum = g.id % @MTextCount
  WHERE p.person_id = @PersonId;

  UPDATE eh
  SET eh.NAME = mock.words,
    eh.INSTITUTE = mock.word,
    eh.DIPLOMA_NUMBER = ABS(CHECKSUM(NewId()))
  FROM SK_EDUCATION_HISTORY AS eh
    JOIN mock_text_view AS mock ON mock.rownum = eh.EDUCATION_HISTORY_ID % @MTextCount
  WHERE eh.PERSON_ID = @PersonId;

  UPDATE no
  SET no.NOTE_TEXT = mock.paragraph,
    no.NOTE_LINK = CASE WHEN no.NOTE_LINK IS NULL THEN NULL ELSE CAST(ABS(CHECKSUM(NewId())) AS VARCHAR(MAX)) END
  FROM SK_NOTE AS no
    JOIN mock_text_view AS mock ON mock.rownum = no.NOTE_ID % @MTextCount
  WHERE no.PERSON_ID = @PersonId;

  UPDATE pe
  SET
    pe.INSTITUTE = mock.word,
    pe.DIPLOMA_NUMBER = ABS(CHECKSUM(NewId()))
  FROM SK_PERSON_EDUCATION AS pe
    JOIN mock_text_view AS mock ON mock.rownum = pe.PERSON_EDUCATION_ID % @MTextCount
  WHERE pe.PERSON_ID = @PersonId;

  UPDATE pea
  SET
    pea.RATIONALE = mock.words
  FROM SK_PERSON_EDUCATION_ADVICE AS pea
    JOIN mock_text_view AS mock ON mock.rownum = pea.PERSON_EDUCATION_ADVICE_ID % @MTextCount
  WHERE pea.ADVISED_TO = @PersonId
        AND pea.RATIONALE IS NOT NULL;

  UPDATE pfa
  SET
    pfa.RATIONALE = mock.words
  FROM SK_PERSON_FUNCTION_ADVICE AS pfa
    JOIN mock_text_view AS mock ON mock.rownum = pfa.PERSON_FUNCTION_ADVICE_ID % @MTextCount
  WHERE pfa.ADVISED_TO = @PersonId
        AND pfa.RATIONALE IS NOT NULL;

  UPDATE ppe
  SET
    ppe.MOTIVATION = mock.words
  FROM SK_PERSON_POP_EDUCATION AS ppe
    JOIN SK_PERSON_POP AS pop ON ppe.PERSON_POP_ID = pop.PERSON_POP_ID
    JOIN mock_text_view AS mock ON mock.rownum = ppe.PERSON_POP_EDUCATION_ID % @MTextCount
  WHERE pop.PERSON_ID = @PersonId;

  UPDATE ppf
  SET
    ppf.MOTIVATION = mock.words
  FROM SK_PERSON_POP_FUNCTIONPROFILEREVISION AS ppf
    JOIN SK_PERSON_POP AS pop ON ppf.PERSON_POP_ID = pop.PERSON_POP_ID
    JOIN mock_text_view AS mock ON mock.rownum = ppf.PERSON_POP_FUNCTIONPROFILEREVISION_ID % @MTextCount
  WHERE pop.PERSON_ID = @PersonId;

  UPDATE r
  SET
    r.DESCRIPTION = CASE WHEN r.DESCRIPTION IS NULL THEN NULL ELSE mock.words END,
    r.AGREEMENTS_TEXT = CASE WHEN r.AGREEMENTS_TEXT IS NULL THEN NULL ELSE mock.paragraph END,
    r.NOTES = CASE WHEN r.NOTES IS NULL THEN NULL ELSE (SELECT paragraph FROM mock_text_view WHERE rownum = (r.REVIEW_ID + 1) % @MTextCount) END
  FROM SK_REVIEW AS r
    JOIN SK_EMPLOYMENT e ON r.REVIEWEE_EMPLOYMENT_ID = e.EMPLOYMENT_ID
    JOIN mock_text_view AS mock ON mock.rownum = r.REVIEW_ID % @MTextCount
  WHERE (r.DESCRIPTION IS NOT NULL OR
         r.AGREEMENTS_TEXT IS NOT NULL OR
         r.NOTES IS NOT NULL)
        AND e.PERSON_ID = @PersonId;

  END TRY
  BEGIN CATCH
  IF @@TRANCOUNT > 0
    BEGIN
      ROLLBACK TRANSACTION AnonimizeSavePoint; -- rollback to AnonimizeSavePoint
    END
  END CATCH
  COMMIT TRANSACTION
END
go

