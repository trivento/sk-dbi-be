CREATE TRIGGER [dbo].[SK_ANSWER_TimeStamps] ON [dbo].[SK_ANSWER]
  AFTER INSERT, UPDATE
AS
  BEGIN

    SET NOCOUNT ON;

    IF TRIGGER_NESTLEVEL() > 1
      RETURN

    -- A bit of magic: A row that has been updated shows in the 'inserted' and 'deleted' tables on SQL Server --
    UPDATE SK_ANSWER
    SET created_on_utc = CASE WHEN deleted.ANSWERSET_ID IS NULL THEN GETUTCDATE() ELSE deleted.created_on_utc END,
      last_edit_on_utc = GETUTCDATE()
    FROM inserted
      LEFT JOIN deleted ON inserted.ANSWERSET_ID = deleted.ANSWERSET_ID
        AND inserted.QUESTION_ID = deleted.QUESTION_ID
    WHERE inserted.ANSWERSET_ID = SK_ANSWER.ANSWERSET_ID
      AND inserted.QUESTION_ID = SK_ANSWER.QUESTION_ID;

  END
go

