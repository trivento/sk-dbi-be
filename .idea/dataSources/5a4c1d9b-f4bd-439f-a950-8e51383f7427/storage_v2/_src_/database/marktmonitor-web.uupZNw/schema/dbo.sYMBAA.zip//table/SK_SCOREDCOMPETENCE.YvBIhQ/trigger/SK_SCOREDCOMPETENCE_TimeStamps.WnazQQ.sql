CREATE TRIGGER [dbo].[SK_SCOREDCOMPETENCE_TimeStamps] ON [dbo].[SK_SCOREDCOMPETENCE]
  AFTER INSERT, UPDATE
AS
  BEGIN

    SET NOCOUNT ON;

    IF TRIGGER_NESTLEVEL() > 1
      RETURN

    -- A bit of magic: A row that has been updated shows in the 'inserted' and 'deleted' tables on SQL Server --
    UPDATE SK_SCOREDCOMPETENCE
    SET created_on_utc = CASE WHEN deleted.SCOREDCOMPETENCE_ID IS NULL THEN GETUTCDATE() ELSE deleted.created_on_utc END,
      last_edit_on_utc = GETUTCDATE()
    FROM inserted
      LEFT JOIN deleted ON inserted.SCOREDCOMPETENCE_ID = deleted.SCOREDCOMPETENCE_ID
    WHERE inserted.SCOREDCOMPETENCE_ID = SK_SCOREDCOMPETENCE.SCOREDCOMPETENCE_ID;

  END
go

