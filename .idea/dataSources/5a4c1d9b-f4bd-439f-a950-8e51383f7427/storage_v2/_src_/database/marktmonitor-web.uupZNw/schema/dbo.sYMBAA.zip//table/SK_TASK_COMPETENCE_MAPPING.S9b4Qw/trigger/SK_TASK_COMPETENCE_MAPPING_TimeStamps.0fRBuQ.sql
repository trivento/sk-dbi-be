CREATE TRIGGER [dbo].[SK_TASK_COMPETENCE_MAPPING_TimeStamps] ON [dbo].[SK_TASK_COMPETENCE_MAPPING]
  AFTER INSERT, UPDATE
AS
  BEGIN

    SET NOCOUNT ON;

    IF TRIGGER_NESTLEVEL() > 1
      RETURN

    -- A bit of magic: A row that has been updated shows in the 'inserted' and 'deleted' tables on SQL Server --
    UPDATE SK_TASK_COMPETENCE_MAPPING
    SET created_on_utc = CASE WHEN deleted.TASK_COMPETENCE_MAPPING_ID IS NULL THEN GETUTCDATE() ELSE deleted.created_on_utc END,
      last_edit_on_utc = GETUTCDATE()
    FROM inserted
      LEFT JOIN deleted ON inserted.TASK_COMPETENCE_MAPPING_ID = deleted.TASK_COMPETENCE_MAPPING_ID
    WHERE inserted.TASK_COMPETENCE_MAPPING_ID = SK_TASK_COMPETENCE_MAPPING.TASK_COMPETENCE_MAPPING_ID;

  END
go

