CREATE TRIGGER trg_sk_theme_update
  ON sk_theme
AFTER UPDATE
AS
  UPDATE sk_theme
  SET last_edit_datetime = GETUTCDATE()
  WHERE ID IN (SELECT DISTINCT ID FROM Inserted);
go

