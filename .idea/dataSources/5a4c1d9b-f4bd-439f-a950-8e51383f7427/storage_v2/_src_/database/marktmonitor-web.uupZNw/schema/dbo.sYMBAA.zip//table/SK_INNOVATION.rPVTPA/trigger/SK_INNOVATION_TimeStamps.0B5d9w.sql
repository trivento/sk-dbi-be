CREATE TRIGGER [dbo].[SK_INNOVATION_TimeStamps] ON [dbo].[SK_INNOVATION]
  AFTER INSERT, UPDATE
AS
  BEGIN

    SET NOCOUNT ON;

    IF TRIGGER_NESTLEVEL() > 1
      RETURN

    -- A bit of magic: A row that has been updated shows in the 'inserted' and 'deleted' tables on SQL Server --
    UPDATE SK_INNOVATION
    SET created_on_utc = CASE WHEN deleted.INNOVATION_ID IS NULL THEN GETUTCDATE() ELSE deleted.created_on_utc END,
      last_edit_on_utc = GETUTCDATE()
    FROM inserted
      LEFT JOIN deleted ON inserted.INNOVATION_ID = deleted.INNOVATION_ID
    WHERE inserted.INNOVATION_ID = SK_INNOVATION.INNOVATION_ID;

  END
go

