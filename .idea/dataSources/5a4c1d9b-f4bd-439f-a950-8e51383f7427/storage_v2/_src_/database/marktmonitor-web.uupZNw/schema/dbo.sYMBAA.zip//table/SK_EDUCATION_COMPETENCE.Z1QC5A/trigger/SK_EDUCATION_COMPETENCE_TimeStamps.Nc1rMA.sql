CREATE TRIGGER [dbo].[SK_EDUCATION_COMPETENCE_TimeStamps] ON [dbo].[SK_EDUCATION_COMPETENCE]
  AFTER INSERT, UPDATE
AS
  BEGIN

    SET NOCOUNT ON;

    IF TRIGGER_NESTLEVEL() > 1
      RETURN

    -- A bit of magic: A row that has been updated shows in the 'inserted' and 'deleted' tables on SQL Server --
    UPDATE SK_EDUCATION_COMPETENCE
    SET created_on_utc = CASE WHEN deleted.EDUCATION_COMPETENCE_ID IS NULL THEN GETUTCDATE() ELSE deleted.created_on_utc END,
      last_edit_on_utc = GETUTCDATE()
    FROM inserted
      LEFT JOIN deleted ON inserted.EDUCATION_COMPETENCE_ID = deleted.EDUCATION_COMPETENCE_ID
    WHERE inserted.EDUCATION_COMPETENCE_ID = SK_EDUCATION_COMPETENCE.EDUCATION_COMPETENCE_ID;

  END
go

