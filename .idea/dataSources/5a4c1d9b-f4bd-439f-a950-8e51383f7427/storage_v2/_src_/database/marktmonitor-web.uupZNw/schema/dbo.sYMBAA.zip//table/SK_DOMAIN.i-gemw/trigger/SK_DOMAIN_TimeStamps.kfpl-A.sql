CREATE TRIGGER [dbo].[SK_DOMAIN_TimeStamps] ON [dbo].[SK_DOMAIN]
  AFTER INSERT, UPDATE
AS
  BEGIN

    SET NOCOUNT ON;

    IF TRIGGER_NESTLEVEL() > 1
      RETURN

    -- A bit of magic: A row that has been updated shows in the 'inserted' and 'deleted' tables on SQL Server --
    UPDATE SK_DOMAIN
    SET created_on_utc = CASE WHEN deleted.DOMAIN_ID IS NULL THEN GETUTCDATE() ELSE deleted.created_on_utc END,
      last_edit_on_utc = GETUTCDATE()
    FROM inserted
      LEFT JOIN deleted ON inserted.DOMAIN_ID = deleted.DOMAIN_ID
    WHERE inserted.DOMAIN_ID = SK_DOMAIN.DOMAIN_ID;

  END
go

